// Import the functions we want to test
const {
    generateQuestion,
    getRandomEmoji,
    getEmojiName,
    handleAnswerSubmission,
    handleNextQuestion,
    endGame,
    restartGame,
    changeTheme,
    applyTheme
} = require('./script.js');

describe('Question Generation', () => {
    test('generateQuestion returns valid numbers that sum to 10 or less', () => {
        const question = generateQuestion();
        expect(question.num1).toBeGreaterThanOrEqual(1);
        expect(question.num1).toBeLessThanOrEqual(9);
        expect(question.num2).toBeGreaterThanOrEqual(1);
        expect(question.num2).toBeLessThanOrEqual(9);
        expect(question.num1 + question.num2).toBeLessThanOrEqual(10);
    });

    test('getRandomEmoji returns a valid emoji', () => {
        const emoji = getRandomEmoji();
        expect(emoji).toMatch(/[\u{1F300}-\u{1F9FF}]/u);
    });

    test('getEmojiName returns correct name for known emojis', () => {
        expect(getEmojiName('🍎')).toBe('apples');
        expect(getEmojiName('🚗')).toBe('cars');
        expect(getEmojiName('🐶')).toBe('dogs');
    });
});

describe('Game Logic', () => {
    let mockElements;

    beforeEach(() => {
        // Mock DOM elements
        mockElements = {
            answerInput: { value: '', disabled: false },
            submitAnswerBtn: { disabled: false },
            nextQuestionBtn: { classList: { remove: jest.fn(), add: jest.fn() } },
            feedbackArea: { innerHTML: '' },
            progressBar: { value: 0 },
            gameArea: { classList: { add: jest.fn(), remove: jest.fn() } },
            resultsArea: { classList: { add: jest.fn(), remove: jest.fn() } },
            correctAnswersDisplay: { textContent: '' },
            timeTakenDisplay: { textContent: '' },
            scorePercentageDisplay: { textContent: '' }
        };

        // Mock global variables
        global.currentQuestionIndex = 0;
        global.score = 0;
        global.secondsElapsed = 0;
        global.questions = [
            { num1: 2, num2: 3, emoji: '🍎', answer: 5 },
            { num1: 1, num2: 4, emoji: '🚗', answer: 5 }
        ];
    });

    test('handleAnswerSubmission with correct answer', () => {
        mockElements.answerInput.value = '5';
        handleAnswerSubmission(mockElements);
        
        expect(mockElements.feedbackArea.innerHTML).toContain('Correct');
        expect(mockElements.submitAnswerBtn.disabled).toBe(true);
        expect(mockElements.answerInput.disabled).toBe(true);
        expect(score).toBe(1);
    });

    test('handleAnswerSubmission with incorrect answer', () => {
        mockElements.answerInput.value = '6';
        handleAnswerSubmission(mockElements);
        
        expect(mockElements.feedbackArea.innerHTML).toContain('Incorrect');
        expect(mockElements.nextQuestionBtn.classList.remove).toHaveBeenCalledWith('is-hidden');
    });

    test('endGame calculates and displays correct score', () => {
        score = 7;
        secondsElapsed = 120;
        endGame(mockElements);
        
        expect(mockElements.correctAnswersDisplay.textContent).toBe('7');
        expect(mockElements.timeTakenDisplay.textContent).toBe('120s');
        expect(mockElements.scorePercentageDisplay.textContent).toBe('70');
    });
});

describe('Theme Management', () => {
    let mockElements;

    beforeEach(() => {
        mockElements = {
            progressBar: { classList: { remove: jest.fn(), add: jest.fn() } },
            submitAnswerBtn: { classList: { remove: jest.fn(), add: jest.fn() } },
            retakeBtn: { classList: { remove: jest.fn(), add: jest.fn() } },
            nextQuestionBtn: { classList: { remove: jest.fn(), add: jest.fn() } },
            gameContainer: { classList: { remove: jest.fn(), add: jest.fn() } }
        };
    });

    test('changeTheme selects a valid theme', () => {
        const theme = changeTheme();
        expect(themes).toContain(theme);
    });

    test('applyTheme updates all elements with new theme', () => {
        applyTheme('is-emerald', mockElements);
        
        expect(mockElements.progressBar.classList.add).toHaveBeenCalledWith('is-emerald');
        expect(mockElements.submitAnswerBtn.classList.add).toHaveBeenCalledWith('is-emerald');
        expect(mockElements.retakeBtn.classList.add).toHaveBeenCalledWith('is-emerald');
        expect(mockElements.nextQuestionBtn.classList.add).toHaveBeenCalledWith('is-emerald');
        expect(mockElements.gameContainer.classList.add).toHaveBeenCalledWith('is-emerald');
    });
}); 