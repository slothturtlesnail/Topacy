// Helper function to get emoji name
function getEmojiName(emoji) {
    const emojiNames = {
        // Fruits and Vegetables
        '🍎': 'apples',
        '🍊': 'oranges',
        '🍋': 'lemons',
        '🍌': 'bananas',
        '🍉': 'watermelons',
        '🍇': 'grapes',
        '🍓': 'strawberries',
        '🍒': 'cherries',
        '🍑': 'peaches',
        '🍍': 'pineapples',
        '🥥': 'coconuts',
        '🥝': 'kiwis',
        '🍅': 'tomatoes',
        '🍆': 'eggplants',
        '🥑': 'avocados',
        '🥕': 'carrots',
        '🌽': 'corn',
        '🌶️': 'peppers',
        '🍄': 'mushrooms',
        '🥜': 'peanuts',
        
        // Vehicles
        '🚗': 'cars',
        '🚕': 'taxis',
        '🚙': 'SUVs',
        '🚌': 'buses',
        '🚎': 'trolleybuses',
        '🏎️': 'race cars',
        '🚓': 'police cars',
        '🚑': 'ambulances',
        '🚒': 'fire trucks',
        '🚚': 'trucks',
        '🚛': 'articulated lorries',
        '🚜': 'tractors',
        '🛵': 'motorcycles',
        '🚲': 'bicycles',
        
        // Stars and Space
        '⭐': 'stars',
        '🌟': 'glowing stars',
        '✨': 'sparkles',
        '💫': 'dizzy stars',
        '🌠': 'shooting stars',
        '🌙': 'moons',
        '🌞': 'suns',
        '🌝': 'full moons',
        
        // Animals
        '🐶': 'dogs',
        '🐱': 'cats',
        '🐭': 'mice',
        '🐹': 'hamsters',
        '🐰': 'rabbits',
        '🦊': 'foxes',
        '🐻': 'bears',
        '🐼': 'pandas',
        '🐨': 'koalas',
        '🐯': 'tigers',
        '🦁': 'lions',
        '🐮': 'cows',
        '🐷': 'pigs',
        '🐸': 'frogs',
        '🐵': 'monkeys',
        
        // Birds
        '🐔': 'chickens',
        '🐧': 'penguins',
        '🦆': 'ducks',
        '🦅': 'eagles',
        '🦉': 'owls',
        '🦇': 'bats',
        '🦜': 'parrots',
        
        // Sea Creatures
        '🐠': 'fish',
        '🐟': 'fish',
        '🐡': 'blowfish',
        '🦈': 'sharks',
        '🐋': 'whales',
        '🐳': 'whales',
        '🐬': 'dolphins',
        '🐙': 'octopuses',
        '🦑': 'squids',
        '🦀': 'crabs',
        
        // Insects
        '🐞': 'ladybugs',
        '🐝': 'bees',
        '🐛': 'bugs',
        '🦋': 'butterflies',
        '🐌': 'snails',
        '🐜': 'ants',
        '🦗': 'crickets',
        
        // Toys and Games
        '🎮': 'game controllers',
        '🎲': 'dice',
        '🎯': 'darts',
        '🎨': 'paint palettes',
        '🎭': 'masks',
        '🎪': 'circus tents',
        '🎢': 'roller coasters',
        '🎡': 'ferris wheels',
        
        // Sports
        '⚽': 'soccer balls',
        '🏀': 'basketballs',
        '🏈': 'footballs',
        '⚾': 'baseballs',
        '🎾': 'tennis balls',
        '🏐': 'volleyballs',
        '🏉': 'rugby balls',
        '🎱': 'pool balls'
    };
    return emojiNames[emoji] || 'items';
}

// Global constants and utility functions for testability
const emojis = ['🍎', '🍊', '🍋', '🍌', '🍉', '🍇', '🍓', '🍒', '🍑', '🍍', '🥥', '🥝', '🍅', '🍆', '🥑', '🥕', '🌽', '🌶️', '🍄', '🥜', '🚗', '🚕', '🚙', '🚌', '🚎', '🏎️', '🚓', '🚑', '🚒', '🚚', '🚛', '🚜', '🛵', '🚲', '⭐', '🌟', '✨', '💫', '🌠', '🌙', '🌞', '🌝', '🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯', '🦁', '🐮', '🐷', '🐸', '🐵', '🐔', '🐧', '🦆', '🦅', '🦉', '🦇', '🦜', '🐠', '🐟', '🐡', '🦈', '🐋', '🐳', '🐬', '🐙', '🦑', '🦀', '🐞', '🐝', '🐛', '🦋', '🐌', '🐜', '🦗', '🎮', '🎲', '🎯', '🎨', '🎭', '🎪', '🎢', '🎡', '⚽', '🏀', '🏈', '⚾', '🎾', '🏐', '🏉', '🎱'];
const totalQuestions = 10;
const themes = [
    'is-emerald',    // Green
    'is-sky',        // Blue
    'is-amber',      // Yellow
    'is-rose',       // Pink
    'is-violet',     // Purple
    'is-teal',       // Teal
    'is-orange',     // Orange
    'is-fuchsia',    // Fuchsia
    'is-indigo',     // Indigo
    'is-cyan'        // Cyan
];
let questions = []; // Will now store { num1, num2, emoji, answer }
let currentTheme = themes[0]; // Default theme

// Sound Effects Management
const sounds = {
    correct: null,
    incorrect: null,
    click: null
};

function initializeSounds() {
    try {
        sounds.correct = new Audio('sounds/correct.mp3');
        sounds.incorrect = new Audio('sounds/incorrect.mp3');
        sounds.click = new Audio('sounds/click.mp3'); // Generic click sound
        // You can preload sounds if necessary, e.g.:
        // Object.values(sounds).forEach(sound => sound?.load());
    } catch (e) {
        console.error("Error initializing audio files. Make sure sound files exist in a 'sounds' folder.", e);
    }
}

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function getRandomEmoji() {
    return emojis[Math.floor(Math.random() * emojis.length)];
}

function generateQuestion() {
    let num1 = getRandomInt(1, 9);
    let num2 = getRandomInt(1, 9);
    while (num1 + num2 > 10) {
        num1 = getRandomInt(1, 9);
        num2 = getRandomInt(1, 9);
    }
    const emoji = getRandomEmoji();
    return { num1, num2, emoji, answer: num1 + num2 };
}

function generateAllQuestions() {
    questions = [];
    for (let i = 0; i < totalQuestions; i++) {
        questions.push(generateQuestion());
    }
}

// Theme functions made accessible for testing and for DOMContentLoaded part
let _domElementsForTheme = {}; // To be populated in DOMContentLoaded

function _setDomElementsForTheme(elements) {
    _domElementsForTheme = elements;
}

function applyTheme(theme) {
    if (!_domElementsForTheme.progressBar) {
        // DOM elements not ready, or called in a context without them (e.g. pure test)
        currentTheme = theme; // Still set currentTheme for logic tests
        return;
    }
    
    // Remove old theme classes from all elements
    themes.forEach(t => {
        _domElementsForTheme.progressBar.classList.remove(t);
        _domElementsForTheme.submitAnswerBtn.classList.remove(t);
        _domElementsForTheme.retakeBtn.classList.remove(t);
        _domElementsForTheme.nextQuestionBtn.classList.remove(t);
        _domElementsForTheme.gameContainer.classList.remove(t);
    });

    // Apply new theme to all elements
    _domElementsForTheme.progressBar.classList.add(theme);
    _domElementsForTheme.submitAnswerBtn.classList.add(theme);
    _domElementsForTheme.retakeBtn.classList.add(theme);
    _domElementsForTheme.nextQuestionBtn.classList.add(theme);
    _domElementsForTheme.gameContainer.classList.add(theme);
    
    currentTheme = theme;
}

function changeTheme() {
    // Select a random theme from the available themes
    const newTheme = themes[Math.floor(Math.random() * themes.length)];
    applyTheme(newTheme);
}

function playSound(soundType) {
    if (sounds[soundType]) {
        sounds[soundType].currentTime = 0; // Rewind to start for rapid playback
        sounds[soundType].play().catch(error => {
            // Autoplay restrictions might prevent sound from playing without user interaction
            // Or if the sound file is missing/corrupt after initial load
            console.warn(`Could not play sound: ${soundType}`, error);
        });
    } else {
        console.warn(`Sound type "${soundType}" not found or not initialized.`);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    initializeSounds(); // Initialize sounds when DOM is ready

    // Game state variables
    let currentQuestionIndex = 0;
    let score = 0;
    let timerInterval;
    let secondsElapsed = 0;

    // DOM Elements
    const bodyElement = document.body;
    const gameContainer = document.querySelector('.game-container');
    const progressBar = document.getElementById('progress-bar');
    const timerDisplay = document.getElementById('timer');
    const questionDisplay = document.getElementById('question-display');
    const answerInput = document.getElementById('answer-input');
    const submitAnswerBtn = document.getElementById('submit-answer-btn');
    const feedbackArea = document.getElementById('feedback-area');
    const nextQuestionBtn = document.getElementById('next-question-btn');
    const gameArea = document.getElementById('game-area');
    const resultsArea = document.getElementById('results-area');
    const correctAnswersDisplay = document.getElementById('correct-answers');
    const timeTakenDisplay = document.getElementById('time-taken');
    const scorePercentageDisplay = document.getElementById('score-percentage');
    const retakeBtn = document.getElementById('retake-btn');

    // Pass DOM elements to theme functions
    _setDomElementsForTheme({
        progressBar: progressBar,
        submitAnswerBtn: submitAnswerBtn,
        retakeBtn: document.getElementById('retake-btn'),
        nextQuestionBtn: document.getElementById('next-question-btn'),
        gameContainer: gameContainer
    });

    const transitionSpeed = 300; // ms, should match CSS transition duration

    function updateQuestionContent() {
        const q = questions[currentQuestionIndex];
        // Display using the same emoji for both numbers with line breaks
        const emojiDisplay1 = Array(q.num1).fill(q.emoji).join(' ');
        const emojiDisplay2 = Array(q.num2).fill(q.emoji).join(' ');
        const questionText = `How many ${getEmojiName(q.emoji)} are there?`;
        questionDisplay.innerHTML = `
            <div class="question-text">${questionText}</div>
            <div class="emoji-display">${emojiDisplay1}</div>
            <div class="operator">+</div>
            <div class="emoji-display">${emojiDisplay2}</div>
        `;
        
        answerInput.value = '';
        feedbackArea.textContent = '';
        submitAnswerBtn.disabled = false;
        answerInput.disabled = false;
        nextQuestionBtn.classList.add('is-hidden');
        progressBar.value = currentQuestionIndex;
        
        // Focus the input field
        setTimeout(() => {
            answerInput.focus();
        }, 100); // Small delay to ensure the input is ready
    }

    function displayQuestion(isInitialLoad = false) {
        if (currentQuestionIndex < totalQuestions) {
            if (isInitialLoad) {
                updateQuestionContent();
                questionDisplay.classList.remove('question-enter', 'question-enter-active', 'question-exit', 'question-exit-active'); // Clear any existing animation classes
                questionDisplay.classList.add('question-enter');
                requestAnimationFrame(() => {
                    questionDisplay.classList.add('question-enter-active');
                });
            } else {
                questionDisplay.classList.remove('question-enter-active');
                questionDisplay.classList.add('question-exit');
                requestAnimationFrame(() => {
                    questionDisplay.classList.add('question-exit-active');
                });

                setTimeout(() => {
                    updateQuestionContent();
                    questionDisplay.classList.remove('question-exit', 'question-exit-active');
                    questionDisplay.classList.add('question-enter');
                    requestAnimationFrame(() => {
                        questionDisplay.classList.add('question-enter-active');
                    });
                }, transitionSpeed);
            }
        } else {
            endGame();
        }
    }

    function startTimer() {
        secondsElapsed = 0;
        timerDisplay.textContent = `${secondsElapsed}s`;
        if(timerInterval) clearInterval(timerInterval); // Clear existing timer before starting a new one
        timerInterval = setInterval(() => {
            secondsElapsed++;
            timerDisplay.textContent = `${secondsElapsed}s`;
        }, 1000);
    }

    function stopTimer() {
        clearInterval(timerInterval);
    }

    function handleAnswerSubmission() {
        const userAnswer = answerInput.value.trim();
        
        // Prevent submitting blank answers
        if (userAnswer === '') {
            feedbackArea.innerHTML = '<p class="has-text-danger">Please enter an answer!</p>';
            answerInput.focus();
            return;
        }

        const parsedAnswer = parseInt(userAnswer);
        const correctAnswer = questions[currentQuestionIndex].answer;
        
        if (parsedAnswer === correctAnswer) {
            feedbackArea.innerHTML = '<p class="has-text-success">Correct! 🎉</p>';
            score++;
            submitAnswerBtn.disabled = true;
            answerInput.disabled = true;
            
            // Automatically move to next question after a short delay
            setTimeout(() => {
                handleNextQuestion();
            }, 1000);
        } else {
            feedbackArea.innerHTML = `<p class="has-text-danger">Incorrect. The correct answer is ${correctAnswer}.</p>`;
            submitAnswerBtn.disabled = true;
            answerInput.disabled = true;
            nextQuestionBtn.classList.remove('is-hidden');
        }
        
        progressBar.value = currentQuestionIndex + 1;
    }

    function handleNextQuestion() {
        if (currentQuestionIndex < totalQuestions - 1) {
            currentQuestionIndex++;
            displayQuestion();
        } else {
            endGame();
        }
    }

    function endGame() {
        stopTimer();
        // Fade out game area, fade in results area
        gameArea.classList.add('visually-hidden');
        setTimeout(() => {
            gameArea.classList.add('is-hidden'); 
            resultsArea.classList.remove('is-hidden');
            resultsArea.classList.remove('visually-hidden');
            resultsArea.classList.add('visible');
        }, transitionSpeed); 

        correctAnswersDisplay.textContent = score;
        timeTakenDisplay.textContent = `${secondsElapsed}s`;
        const percentage = (score / totalQuestions) * 100;
        scorePercentageDisplay.textContent = percentage.toFixed(0);
    }

    function restartGame() {
        currentQuestionIndex = 0;
        score = 0;
        secondsElapsed = 0;
        nextQuestionBtn.textContent = 'Next Question'; 
        generateAllQuestions(); // Uses global questions array
        
        resultsArea.classList.add('is-hidden');
        resultsArea.classList.remove('visible');
        resultsArea.classList.add('visually-hidden');
        
        gameArea.classList.remove('is-hidden');
        gameArea.classList.remove('visually-hidden');
        
        changeTheme(); // Change theme only when game restarts

        startTimer();
        displayQuestion(true);
        progressBar.value = 0;
        // Focus will be set in updateQuestionContent
    }

    // Event Listeners
    submitAnswerBtn.addEventListener('click', handleAnswerSubmission);
    answerInput.addEventListener('keypress', function(event) {
        if (event.key === 'Enter' && !submitAnswerBtn.disabled) {
            handleAnswerSubmission();
        }
    });
    nextQuestionBtn.addEventListener('click', handleNextQuestion);
    retakeBtn.addEventListener('click', restartGame);

    // Add sound to button clicks
    submitAnswerBtn.addEventListener('click', () => playSound('click'));
    nextQuestionBtn.addEventListener('click', () => playSound('click'));
    retakeBtn.addEventListener('click', () => playSound('click'));
    // Consider adding to answerInput on focus or keypress if desired

    // Initial game setup
    changeTheme(); // Change theme when game first loads
    generateAllQuestions(); // Uses global questions array
    startTimer();
    displayQuestion(true);
});

// Export functions for testing
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        getEmojiName,
        getRandomEmoji,
        generateQuestion,
        handleAnswerSubmission,
        handleNextQuestion,
        endGame,
        restartGame,
        changeTheme,
        applyTheme,
        emojis,
        themes,
        totalQuestions
    };
} 